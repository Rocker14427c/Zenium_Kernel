# AnyKernel3 Ramdisk Mod Script
# osm0sis @ xda-developers

### AnyKernel setup
# begin properties
properties() { '
kernel.string=Zenium SUSFS v2.3.0 by Rocker14427c @ XDA
do.devicecheck=0
do.modules=0
do.systemless=1
do.cleanup=1
do.cleanuponabort=0
device.name1=even
device.name2=RMX1941
device.name3=RMX1945
supported.versions=
supported.patchlevels=
'; } # end properties

# shell variables
block=/dev/block/bootdevice/by-name/boot;
is_slot_device=0;
ramdisk_compression=auto;
patch_vbmeta_flag=auto;

# import functions/variables and setup patching - leave this here
. tools/ak3-core.sh;

dump_boot;

write_boot;
## end install
